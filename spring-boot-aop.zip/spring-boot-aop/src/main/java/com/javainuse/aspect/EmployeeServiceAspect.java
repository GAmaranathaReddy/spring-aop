package com.javainuse.aspect;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingHandler {
	
	Logger log = LoggerFactory.getLogger(this.getClass());
	 
    @Pointcut("execution(*  com.javainuse.controller.*.*(..)))")
    public void controllerPointcut() {
    }
    
    @Pointcut("execution(* com.javainuse.service.*.*(..)))")
    public void servicePointcut() {
    }
  
    @AfterReturning(value = "controllerPointcut() || servicePointcut()", returning="returnValue")
	public void afterReturnAdvice(Object returnValue) {
    	log.info("After return  method : "+ returnValue);
	}
    
    @Around("controllerPointcut() || servicePointcut()")
    public Object excutionTimeCal(ProceedingJoinPoint joinPoint) throws Throwable {         
        long start = System.currentTimeMillis();
        try {
            String className = joinPoint.getSignature().getDeclaringTypeName();
            String methodName = joinPoint.getSignature().getName();
            Object result = joinPoint.proceed();
            long elapsedTime = System.currentTimeMillis() - start;
            log.info("Method " + className + "." + methodName + " ()" + " execution time : "
                    + elapsedTime + " ms");         
            return result;
        } catch (IllegalArgumentException e) {
        	log.info("Illegal argument " + Arrays.toString(joinPoint.getArgs()) + " in "
                    + joinPoint.getSignature().getName() + "()");
            throw e;
        }
    }
}

}
